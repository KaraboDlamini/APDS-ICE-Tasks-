const https = require('https');
const fs = require('fs');
const express = require('express');
const app = express();
const PORT = 8088

// SSL certificate paths
const options = {
  key: fs.readFileSync('./keys/privatekey.key'),
  cert: fs.readFileSync('./keys/certificate.crt')
};

// Basic route
app.get('/', (req, res) => {
  res.send('Hello, HTTPS world!');
});

// Create HTTPS server
https.createServer(options, app).listen(PORT, () => {
  console.log(`HTTPS Server running on PORT ${PORT}`);
});
